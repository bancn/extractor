// clion/src/main/java/com/myplugin/actions/CLionAction.java
package com.myplugin.actions;

import com.intellij.openapi.actionSystem.AnActionEvent;
import org.jetbrains.annotations.NotNull;

public class CLionAction extends CommonAction {
    @Override
    public void actionPerformed(@NotNull AnActionEvent e) {
        // CLion 特定的实现
    }
}

// common/src/main/java/com/myplugin/actions/CommonAction.java
package com.myplugin.actions;

import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import org.jetbrains.annotations.NotNull;

public abstract class CommonAction extends AnAction {
    public CommonAction() {
        super("Common Action", "Description of common action", null);
    }

    @Override
    public abstract void actionPerformed(@NotNull AnActionEvent e);
}

// android-studio/src/main/java/com/myplugin/actions/AndroidStudioAction.java
package com.myplugin.actions;

import com.intellij.openapi.actionSystem.AnActionEvent;
import org.jetbrains.annotations.NotNull;

public class AndroidStudioAction extends CommonAction {
    @Override
    public void actionPerformed(@NotNull AnActionEvent e) {
        // Android Studio 特定的实现
    }
}
